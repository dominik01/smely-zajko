/* 
 * File:   KomuniakciaWeb.cpp
 * Author: robotour
 * 
 * Created on December 18, 2014, 12:56 PM
 */

#include "KomuniakciaWeb.h"
#include <iostream>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <sstream>
#include <string>
#include "fstream"

#define POSLI_POLOHU "wget -O /dev/null -q \"http://dai.fmph.uniba.sk/projects/smelyzajko/sprievodca/posli_polohu.php?x=%s&y=%s&poloha=%s\""
#define STAV_VYPINACA "wget -q http://dai.fmph.uniba.sk/projects/smelyzajko/sprievodca/data/command.txt"


using namespace std;

KomuniakciaWeb::KomuniakciaWeb() {
    system("rm -f command.txt*");
}
//http://dai.fmph.uniba.sk/projects/smelyzajko/sprievodca/posli_polohu.php?suradnice=%s

void KomuniakciaWeb::send(string positionRoom, int X, int Y) {
    charDoor = positionRoom.c_str();    
 
    stringstream ss;
    stringstream ss2;
    ss << X;
    ss2 << Y;
    string sur_X = ss.str();
    string sur_Y = ss2.str();
  
    suradnice_X = sur_X.c_str();
    suradnice_Y = sur_Y.c_str();
    sprintf(prikaz, POSLI_POLOHU, suradnice_X,suradnice_Y,charDoor);
    system(prikaz);
}   

int KomuniakciaWeb::recv() {
    
    system(STAV_VYPINACA);
    
    ifstream commandFile;
    commandFile.open("command.txt");
    
    if (commandFile.is_open()) {
        getline(commandFile, line);
        commandFile.close();
        system("rm command.txt*");
        stringValue << line;
        stringValue >> intValue;
        return intValue;
    } else {
        cout << "Unable to open file" << endl;
    }
    return -1;
}