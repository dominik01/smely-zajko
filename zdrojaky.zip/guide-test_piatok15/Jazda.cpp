/* 
 * File:   Jazda.cpp
 * Author: robotour
 * 
 * Created on December 11, 2014, 10:57 AM
 */

#include <iostream>
#include "Jazda.h"
#include "SbotThread.h"
#include <vector>
#include "oneLine.h"
#include "rapidxml.hpp"
#include "fstream"
#include <math.h>
#include <unistd.h>
#include <string.h>
#include "webThread.h"

using namespace std;
using namespace rapidxml;

SbotThread sbot;

Jazda::Jazda() {
    index = 0;
    aktualnaPozicia = "vytah";
    startPosition = 4578; //2500
    position[0] = 0;
    position[1] = 570;
    sign = -1;
    width = 0; height = 0;
    smerOtocenia = 0;
}

int Jazda::je_naMape(int newPosition) {
    if (newPosition < 0) {
        return 0;
    } else if (index == 0) {
        if (newPosition > width) {
            return 0;
        }
    } else {
        if (newPosition > height) {
            return 0;
        }
    }
    return 1;
}

void Jazda::update_position(int lstep, int rstep){
    double dist;
    int newPosition;
    string noveDvere;
    dist = (lstep*1.33 + rstep*1.33) / 2;
    newPosition = startPosition + (sign*(round(dist)));
    if (je_naMape(newPosition)) {
        position[index] = newPosition;
        int lineId = get_lineId(position[0], position[1]);
        noveDvere = get_doors(lineId);
        if (noveDvere != "None") {
            aktualnaPozicia  = noveDvere;
        }
        positionX = position[0];
        positionY = position[1];
    }
    cout << "aktualna pozicia: "<<position[0]<<" "<<position[1]<<", dvere: "<<aktualnaPozicia<<endl;
}

string Jazda::get_doors(int lineId) {
	for (unsigned int i=0; i<sizeof(map)/sizeof(*map); i++) {
                if (map[i].id == lineId) {
                    return map[i].dvere;
		}
	}
	return "None";
}

void Jazda::otocka180() {
    cout << "Otocene o 180 stupnov" << endl;
    sbot.setSpeed(0);
    sbot.setDirection(80);
    sbot.setSpeed(4);
    sleep(4);
    sbot.setSpeed(0);
    sbot.setDirection(0);
    startPosition = position[index] + sign*(abs(startPosition-position[index]));
    sign = -1 * sign;
    smerOtocenia = !smerOtocenia;
}

void Jazda::najdi_cestu(string room) {
    int cieloveDvere = -1, aktualneDvere = -1;
    for (int i=0; i < sizeof(poleDvere)/sizeof(*poleDvere); i++) {
        if (poleDvere[i] == room) {
            cieloveDvere = i;
        } else if (poleDvere[i] == aktualnaPozicia) {
            aktualneDvere = i;
        }
    }
    if (!smerOtocenia) {
        if (cieloveDvere > aktualneDvere) {
            // ciel je pred robotom
            if (abs(aktualneDvere-cieloveDvere) < sizeof(poleDvere)/sizeof(*poleDvere)/2) {
                cout << "Netreba sa otacat." << endl;
            } else {
                otocka180();
            }
        } else {
            // ciel je za robotom
            if (abs(aktualneDvere-cieloveDvere) < sizeof(poleDvere)/sizeof(*poleDvere)/2) {
                otocka180();
            } else {
                cout << "Netreba sa otacat." << endl;
            }
        }
    }
}

int Jazda::get_lineId(int x, int y) {
	for (unsigned int i=0; i<sizeof(map)/sizeof(*map)-1; i++) {
		if (x == map[i].x2 && x == map[i].x1) {
			if ((map[i].y1 <= y && y < map[i].y2) || (map[i].y2 < y && y <= map[i].y1)) {
				return map[i].id;
			}
		} else if (y == map[i].y2 && y == map[i].y1) {
			if ((map[i].x1 <= x && x < map[i].x2) ||
					(map[i].x2 < x && x <= map[i].x1)) {
				return map[i].id;
			}
		}
	}
        cout << "CHYBA na suradniciach: " << x << " " << y << endl;
	return -1;
}

void Jazda::load_map() {
    int x1, y1, x2, y2, id, i; i=0;
    xml_document<> doc;
    xml_node<> *root_node;
    ifstream theFile("plan.svg");
    vector<char> buffer((istreambuf_iterator<char>(theFile)), istreambuf_iterator<char>());
    buffer.push_back('\0');
    doc.parse<0>(&buffer[0]);

    root_node = doc.first_node("svg");
    width = atoi(root_node->first_attribute("width")->value());
    height = atoi(root_node->first_attribute("height")->value());
    for (xml_node<> *line_node = root_node->first_node("line"); line_node; line_node = line_node->next_sibling()) {
                x1 = atoi(line_node->first_attribute("x1")->value());
                y1 = atoi(line_node->first_attribute("y1")->value());
                x2 = atoi(line_node->first_attribute("x2")->value());
                y2 = atoi(line_node->first_attribute("y2")->value());
                id = atoi(line_node->first_attribute("lineId")->value());
                oneLine u;
                u.add_points(x1,y1,x2,y2);
                u.id = id;
                xml_attribute<> *door = line_node->first_attribute("doors");
                if (door != 0) {
                        u.dvere = door->value();
                        poleDvere[i] = door->value();
                        i++;
                }
                xml_attribute<> *curve = line_node->first_attribute("curve");
                if (curve != 0) {
                        u.curve = atoi(curve->value());
                }
                map[id] = u;
     }
}

int Jazda::v_strede(int left, int right) {
    int angle = 0;
    if ((left < 40) || (right < 40)) {
        angle = 18;
    } else if ((left < 45 || right < 45)) {
        angle = 12;
    } else if ((left < 50 || right < 50)) {
        angle = 7;
    } else if ((left > 100 || right > 100)) {
        angle = -11;
    } else if ((left > 60 || right > 60)) {
        angle = 7;
    } 
    if (left < right) {
        return angle;
    } else {
        return -angle;
    }
    return 0;
}

void Jazda::zaboc(int angle, bool obstacle) {
    cout << "ZABACAM" << endl;
    sbot.setSpeed(0);
    if (obstacle) {
        sbot.ignoreObstacle(1);
        sbot.setSpeed(-3);
        sleep(2);sbot.setSpeed(0);
        sbot.setDirection(angle);
        sbot.setSpeed(3);
        sleep(2);
        sbot.setDirection(0);
        sleep(2);
        sbot.ignoreObstacle(0);
    } else {
        sbot.setSpeed(0);
        sbot.setDirection(angle);
        sbot.setSpeed(3);
        sleep(2);
        sbot.setDirection(0);
    }
}

void Jazda::vyrovnavaj(int angle) {
    sbot.setDirection(angle);
    sleep(4);
    sbot.setDirection(-angle-angle/5);
    sleep(3);
    cout << "KONIEC VYROVNAVANIA" << endl;
}

int Jazda::vrat_uhol_cuvania(int middle) {
    int angle = 0;
    if (middle < 60) {
        angle = 20;
    } else if (middle < 80) {
        angle = 17;
    } else if (middle < 100) {
        angle = 14;
    }
    return angle;
}

void Jazda::cuvaj_od_prekazky(int middle, int left, int right) {
    cout << "Zacinam cuvat od prekazky." << endl;
    int angle = vrat_uhol_cuvania(middle);
    if (angle) {
        if (right > left) {
            angle = -angle;
        }
        sbot.ignoreObstacle(1);
        sbot.setSpeed(-6);
        sbot.setDirection(0);
        sleep(2);
        sbot.setDirection(0);
        sbot.setDirection(-angle);
        sleep(2);
        cout << "VYROVNAVAM POD UHLOM " << angle << endl;
        sbot.setSpeed(0);
        sbot.setDirection(0);
        sbot.ignoreObstacle(0);
    } else {
        angle = 30;
        if (right < left) {
            angle = -angle;
        }
        sbot.ignoreObstacle(1);
        sbot.setSpeed(-6);
        sbot.setDirection(angle);
        sleep(1);
        sbot.setDirection(0);
        sleep(2);
        sbot.setDirection(-angle);
        sleep(2);
        sbot.setSpeed(0);
        sbot.setDirection(0);
        sbot.ignoreObstacle(0);
    } 
}

int Jazda::zakruta(int left, int right) {
    cout << "overujem zakrutu " << left << " " << right << endl;
    if (left > 150 || right > 150) {
        return 75;
        //cout << "zakruta " << left << " " << right << endl;
        int curve = map[get_lineId(position[0], position[1])].curve;
        switch(curve) {
            case 0:{
                return 0;
            }
            case 1:{
                position[0] = 0;
                startPosition = position[1] = 660;
                index = 1;
                sign = 1;
            }
            case 2:{
                startPosition = position[0] = 0;
                position[1] = 3641;
                index = 0;
                sign = 1;
            }
            case 3:{
                position[0] = 4578;
                startPosition = position[1] = 3641;
                index = 1;
                sign = -1;
            }
            case 4:{
                startPosition = position[0] = 4578;
                position[1] = 660;
                index = 0;
                sign = -1;
            }
        }
        if (smerOtocenia) {
            return 75;
        } else {
            return -75;
        }        
    } 
    return 0;
}
