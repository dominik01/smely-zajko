/* 
 * File:   komunikacia.h
 * Author: robotour
 *
 * Created on December 15, 2014, 4:41 PM
 */

#ifndef KOMUNIKACIA_H
#define	KOMUNIKACIA_H
#include <iostream>
#include <vector>

using namespace std;

class KomunikaciaClovek {
public:
    //vector<string> dvera2;
    string poleDvere [55];
    KomunikaciaClovek();
    int valid_input(string room);
    void nacitaj_miestnosti();
    void audio_pozdrav();
    void audio_ciel();
    void audio_nasleduj();
    string input_room();
private:

};

#endif	/* KOMUNIKACIA_H */

