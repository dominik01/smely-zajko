/* 
 * File:   KomuniakciaWeb.h
 * Author: robotour
 *
 * Created on December 18, 2014, 12:56 PM
 */

#ifndef KOMUNIAKCIAWEB_H
#define	KOMUNIAKCIAWEB_H
#include <iostream>
#include <sstream>

#include "camera.h"

using namespace std;

class KomuniakciaWeb {
public:
    KomuniakciaWeb();
    void send(string positionRoom, int X, int Y);
    int recv();
private:
    stringstream stringValue;
    int intValue;
    char prikaz[255];
    char stiahni[255];
    const char * charDoor;
    const char * suradnice_X;
    const char * suradnice_Y;
    string line;
    //ifstream myfile ("command.txt");
};

#endif	/* KOMUNIAKCIAWEB_H */

