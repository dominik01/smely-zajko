/* 
 * File:   main.cpp
 * Author: myron
 *
 * Created on Sobota, 2010, august 14, 17:23
 */

#include <opencv/cv.h>
#include <opencv/highgui.h>
#include "opencv2/objdetect/objdetect.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include <opencv/highgui.h>

#include <cstdlib>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/time.h>
#include <valarray>

#include "SbotThread.h"
#include "BindSerialPorts.h"
#include "rapidxml.hpp"
#include "fstream"
#include "oneLine.h"
#include "Jazda.h"
#include "komClovek.h"
#include "pthread.h"
#include "camera.h"
#include "webThread.h"
//#include "ImuThread.h"

using namespace std;
using namespace rapidxml;
using namespace cv;

FILE* mainLog;
int log_counter=0;
bool autonomy = true;



//void log_data(SbotData sdata, Ll gdata, ImuData idata, double mapAngle, double kmtotarget )
void log_data(SbotData sdata ) //zapis vystupov do suboru, vypis vystupov
{
    time_t t;
    time(&t);
    fprintf(mainLog, " %ld %d %d %d %d %d %d %d %d %d %d %d\n", t, sdata.lstep, sdata.rstep, sdata.lspeed,
        sdata.rspeed, sdata.blocked, sdata.obstacle, sdata.distRL, sdata.distFL, sdata.distM, sdata.distFR, sdata.distRR );

    fflush(mainLog);
    
    //printf("data > %d %d %d %d %d %d %d %d %d %d %d \n", sdata.lstep, sdata.rstep, sdata.lspeed,
      //     sdata.rspeed, sdata.blocked, sdata.obstacle, sdata.distRL, sdata.distFL, sdata.distM, sdata.distFR, sdata.distRR);
}



int main(int argc, char** argv) {
    
    const char *message1 = "argument, ktory neviem preco musim zadat";
    pthread_t camThread;
    pthread_t threadWeb;
//    IplImage* localizationFrame;
    
    //Mat frame2;
            
    setlocale(LC_ALL, "C");
    time_t t;
    time(&t);

    char logname[64];
    sprintf(logname, "logs/%ld.log", t);
    mainLog = fopen( logname, "w");
    if( mainLog == NULL ){
        printf("log cannot be created.\n");
        exit(-1);
    }
    
   printf("idem");
   
    SbotThread sbot;
//    PhoneThread phone(&sbot);

    BindSerialPorts bs;

   // bs.bind( &sbot, &gps, &imu );
    
    bs.bind( &sbot, NULL, NULL );    //ZAKOMENTOVANE 16.12.

    sbot.run();

    sleep(1);
    sbot.setSpeed(1);
    sleep(2);
    sbot.setSpeed(0);

    //imu.run();
    
//    IplImage* frame;
    setlocale(LC_ALL, "C");
    
    autonomy = true;

    bool was_obstacle = false;
    long found_obstacle;
    
    int bakdir = 0;

    time_t tmnow = time(NULL);

    
    int x = pthread_create(&camThread, NULL, kamera_thread, (void*) message1);
    int y = pthread_create(&threadWeb, NULL, web_thread_function, (void*) message1);

    
    Jazda jazda;
    SbotData sdata;
    KomunikaciaClovek comHuman;
    jazda.load_map();
    comHuman.nacitaj_miestnosti();
    int angle = 0, number = 0, osoba = 0;
    string cielovaMiestnost = "None";
    
    sbot.ignoreObstacle(1);
    
    while(!application_quit) {
        
        usleep(10000);
        
        if (turnON) {
        
        if (novyclovek) {
            novyclovek = 0;
            sbot.setDirection(0);
            sbot.setSpeed(0);   
            //comHuman.audio_pozdrav();
            cielovaMiestnost = comHuman.input_room();
            cout << "cielova miestnost: " << cielovaMiestnost << endl;
            //comHuman.audio_nasleduj();
            if (cielovaMiestnost == aktualnaPozicia) {
                clovek = 0;
                } else {
                    jazda.najdi_cestu(cielovaMiestnost);
                }
        } else {
            sbot.setDirection(0);
            sbot.setSpeed(3);
            sbot.setDirection(0);
        }
        
        sdata = sbot.getData();
        jazda.update_position(sdata.lstep, sdata.rstep);
        if (cielovaMiestnost != "None") {
            cout << "........."<< cielovaMiestnost << "__" << aktualnaPozicia << endl;
            if (cielovaMiestnost == aktualnaPozicia) {
                cout << "**************** som v ciely ***************" << endl;
                clovek = 0;
                //comHuman.audio_ciel();
                sbot.setSpeed(0);
                sleep(4);
                sbot.setSpeed(3);
                cielovaMiestnost = "None";
            }
        }
        number++;
        /*if (sdata.obstacle) {
            if (jazda.zakruta(sdata.distRL, sdata.distRR)) {
                sbot.ignoreObstacle(1);
                sbot.setDirection(0);
                sbot.setSpeed(-4);
                sleep(2);
                sbot.setSpeed(0);
                sbot.ignoreObstacle(0);
            }
            jazda.cuvaj_od_prekazky(sdata.distM, sdata.distRL, sdata.distRR);
        }*/
        angle = jazda.zakruta(sdata.distRL, sdata.distRR);
        if (angle) {
            jazda.zaboc(angle, sdata.obstacle);
        }
        if (number > 3) {
            angle = jazda.v_strede(sdata.distRL, sdata.distRR);
            if (angle) {
                jazda.vyrovnavaj(angle);
            }
            number = 0;
        }
        
        //ImuData idata = imu.getData();
        
        if (sdata.obstacle && (!was_obstacle))
        {
            time_t tobs = time(NULL);
            found_obstacle = tobs;
            printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!OBSTACLE\n");
        }
        if ((sdata.obstacle) && (tmnow - found_obstacle > 20))
        {
            printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! BACKING UP\n");
            found_obstacle = found_obstacle +30;
            // cuvat alebo aspon tocit!!
            
            if(true){
                bakdir = -40;
                printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! LEFT\n");
            }
            else{
                bakdir = 40;
                printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! RIGHT\n");
            }
            sbot.ignoreObstacle(true);
            sbot.setDirection( 0 );
            sbot.setSpeed( -3 );
            sleep(4);
            sbot.setDirection( bakdir );
            sbot.setSpeed( 2 );
            sleep(2);
            sbot.setDirection( 0 );
            sbot.setSpeed( 0 );
            sleep(2);
            sbot.ignoreObstacle(false);
        }
        else if (sdata.obstacle)
        {
            printf("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! %ld\n", tmnow - found_obstacle);
            fflush(stdout);
        }
        was_obstacle = sdata.obstacle;

        log_data(sdata);
        

        //cvShowImage( "camera", frame );
        
        //cvReleaseImage( &frame );
        /*
        char c = cvWaitKey(33);
        if( c == 27 ) break;*/
        } else {
            sbot.setSpeed(0);
            sbot.setDirection(0);
            cout << "Program je vypnuty.";
        }
          
    }

    sbot.stop();
    //imu.stop();
    
    //cvReleaseCapture( &capture );
    cvDestroyWindow( "camera" );
    cvDestroyWindow( "debug" );
    
    fclose(mainLog);

    return 0;
}

