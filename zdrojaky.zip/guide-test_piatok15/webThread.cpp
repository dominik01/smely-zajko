#include <cstdlib>
#include <unistd.h>
#include "webThread.h"
#include "KomuniakciaWeb.h"

using namespace std;

int turnON = 1;
int positionX = 0;
int positionY = 0;
string aktualnaPozicia = "None";
KomuniakciaWeb comWeb;

void *web_thread_function(void *ptr) {
    while (!application_quit) {
        usleep(1000000);
        turnON = comWeb.recv();
        comWeb.send(aktualnaPozicia, positionX, positionY);
    }
}