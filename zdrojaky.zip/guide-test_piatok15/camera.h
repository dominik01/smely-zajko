#ifndef CAMERA_H
#define	CAMERA_H

#include <opencv/cv.h>
#include <opencv/highgui.h>
#include "opencv2/objdetect/objdetect.hpp"
#include "opencv2/imgproc/imgproc.hpp"
#include <opencv/highgui.h>



using namespace cv;

const bool START_CAM = 1;
//const bool USE_LOCALIZATION = 0;
const int camera_w = 320;
const int camera_h = 240;

extern int clovek;
extern int novyclovek; 
extern int application_quit;

void init_video();
void *kamera_thread( void *ptr );
bool detectAndDisplay( Mat frame );

#endif	/* CAMERA_H */

