
#include "camera.h"

using namespace std;
using namespace cv;


 /** Global variables */
String face_cascade_name = "haarcascade_frontalface_alt.xml";
String eyes_cascade_name = "haarcascade_eye_tree_eyeglasses.xml";
CascadeClassifier face_cascade;
CascadeClassifier eyes_cascade;
string window_name = "Capture - Face detection";
RNG rng(12345);

int application_quit = 0;
int clovek = 0;
int novyclovek = 0;
int pocitadlo = 0;

void init_video()
{
    FILE* mplayer;
    char *command=(char *)"mplayer tv:// -tv driver=v4l2:device=/dev/video1:immediatemode=0:normid=0:outfmt=YUY2:input=1";

    if ( !(mplayer = (FILE*)popen(command,"r")) ){
        // If fpipe is NULL
        perror("Problems with pipe");
        exit(1);
    }

    char b[1024];

    while ( fgets( b, sizeof b, mplayer) ){
        if( strcmp( b, "Starting playback...\n" )==0){
            break;
        }
        printf("%s", b );
    }

    pclose( mplayer );

    system("clear");
}
 

void *kamera_thread( void *ptr )
{       
    Mat frame2;
    IplImage* empty_frame = cvCreateImage( cvSize( camera_w, camera_h ), 8, 3);

    cvNamedWindow( "camera", CV_WINDOW_AUTOSIZE );
    //cvNamedWindow(     "path", CV_WINDOW_AUTOSIZE );

    cvShowImage( "camera", empty_frame );

    cvMoveWindow( "camera", 1000, 30 );

    CvCapture* capture;
    
    if( !face_cascade.load( face_cascade_name ) ){ printf("--(!)Error loading\n"); return NULL; };
    if( !eyes_cascade.load( eyes_cascade_name ) ){ printf("--(!)Error loading\n"); return NULL; };
   
   if( START_CAM ){
        
        init_video();
       printf("mplayer init video done.\n");

        capture = cvCaptureFromCAM(1);  //(1);
    
   }
    
    while (1) {
        //usleep(2);
        //cout << "***cam***" << endl;
        if (!clovek) {
            //if( capture ) {   
                frame2 = cvQueryFrame( capture );
                if( !frame2.empty() ) {
                    if (detectAndDisplay( frame2 )) {
                        clovek = 1;
                        novyclovek = 1;
                    } else {
                        clovek = 0;
                    } 
                } else { 
                    printf(" --(!) No captured frame -- Break!"); 
                    break; 
                }    
            //}
        }
        
        imshow( "camera", frame2 );

        char c = cvWaitKey(100);
        if( c == 27 ) break;
    }
    
    application_quit = 1;
}

bool detectAndDisplay( Mat frame )
{
  std::vector<Rect> faces;
  Mat frame_gray;


  cvtColor( frame, frame_gray, CV_BGR2GRAY );
  equalizeHist( frame_gray, frame_gray );

  //-- Detect faces
  
  face_cascade.detectMultiScale( frame_gray, faces, 1.1, 2, 0|CV_HAAR_SCALE_IMAGE, Size(30, 30) );
  //cout << faces.size();
  if (faces.size()>0) {
      pocitadlo = pocitadlo + 1; 
  }
  else {
      pocitadlo = 0;
  }
  
  for( size_t i = 0; i < faces.size(); i++ )
  {
    Point center( faces[i].x + faces[i].width*0.5, faces[i].y + faces[i].height*0.5 );
    ellipse( frame, center, Size( faces[i].width*0.5, faces[i].height*0.5), 0, 0, 360, Scalar( 255, 0, 255 ), 4, 8, 0 );

   // Mat faceROI = frame_gray( faces[i] );
   // std::vector<Rect> eyes;

    //-- In each face, detect eyes
    //eyes_cascade.detectMultiScale( faceROI, eyes, 1.1, 2, 0 |CV_HAAR_SCALE_IMAGE, Size(30, 30) );
    
    
/*
    for( size_t j = 0; j < eyes.size(); j++ )
     {
       Point center( faces[i].x + eyes[j].x + eyes[j].width*0.5, faces[i].y + eyes[j].y + eyes[j].height*0.5 );
       int radius = cvRound( (eyes[j].width + eyes[j].height)*0.25 );
       circle( frame, center, radius, Scalar( 255, 0, 0 ), 4, 8, 0 );
     } */
  } 
    
  //-- Show what you got
  //imshow( "camera", frame );
  if (pocitadlo>3){
      pocitadlo=0;
       return (faces.size()>0);
  }
  else {
     return 0;
  }
  // return (faces.size()>0);
 }

