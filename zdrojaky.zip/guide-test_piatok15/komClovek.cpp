/* 
 * File:   komunikacia.cpp
 * Author: robotour
 * 
 * Created on December 15, 2014, 4:41 PM
 */

#include "komClovek.h"
#include <iostream>
#include <stdlib.h>
#include "SFML-2.1/include/SFML/Audio.hpp"
#include <vector>
#include "rapidxml.hpp"
#include "fstream"
#include <unistd.h>
#include <string.h>

using namespace std;
using namespace sf;
using namespace rapidxml;


KomunikaciaClovek::KomunikaciaClovek() {
}

void KomunikaciaClovek::nacitaj_miestnosti() {
    int i; i = 0;
    xml_document<> doc;
    xml_node<> *root_node;
    ifstream theFile("plan.svg");
    vector<char> buffer((istreambuf_iterator<char>(theFile)), istreambuf_iterator<char>());
    buffer.push_back('\0');
    doc.parse<0>(&buffer[0]);

    root_node = doc.first_node("svg");
    for (xml_node<> *line_node = root_node->first_node("line"); line_node; line_node = line_node->next_sibling()) {
                xml_attribute<> *door = line_node->first_attribute("doors");
                //cout << ".........." << door << endl;
                if (door != 0) {
                    poleDvere[i] = door->value();
                    i++;
                }
    }
}

void KomunikaciaClovek::audio_pozdrav() {
    system("mplayer pozdrav.wav");
    /*
    SoundBuffer buffer;
    if (!buffer.loadFromFile("test.wav")) {
        cout << "Subor s nahravkou sa neda nacitat.";
    }
    Sound sound;
    sound.setBuffer(buffer);
    sound.setVolume(100);
    sound.play();
     */
}

void KomunikaciaClovek::audio_nasleduj() {
    system("mplayer nasleduj.wav");
}

void KomunikaciaClovek::audio_ciel() {
    system("mplayer koniec.wav");
}

int KomunikaciaClovek::valid_input(string room) {
    for (int i=0; i<sizeof(poleDvere)/sizeof(*poleDvere); i++) {
        if (poleDvere[i] == room) {
            return 1;
        }
    }
    return 0;
}

string KomunikaciaClovek::input_room() {
    cout << "Hladana miestnost (napriklad I20, I5 ...): ";
    string room = "None";
    while (1) {
        cin >> room;
        if (valid_input(room)) {
                return room;
        } else {
            cout << "Zadany vstup nema pozadovany format. Pozadovany format je napr. I19" << endl;
            cout << "Hladana miestnost: ";
        }
    }
}