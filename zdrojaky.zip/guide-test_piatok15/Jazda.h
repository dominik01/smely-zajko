/* 
 * File:   Jazda.h
 * Author: robotour
 *
 * Created on December 11, 2014, 10:57 AM
 */

#ifndef JAZDA_H
#define	JAZDA_H

#include "oneLine.h"
#include <vector>
#include "KomuniakciaWeb.h"

using namespace std;

class Jazda {
public:
    oneLine map [177];
    int position [2];
    //vector<string> dvera;
    string poleDvere [55];
    //string aktualneDvere;
    KomuniakciaWeb komWeb;
    int smerOtocenia;
    int je_naMape(int newPosition);
    int startPosition, index, sign, width, height;
    int zakruta(int left, int right);
    int v_strede(int left, int right);
    int get_lineId(int x, int y);
    string get_doors(int lineId);
    void najdi_cestu(string room);
    void zaboc(int angle, bool obstacle);
    void cuvaj_od_prekazky(int middle, int left, int right);
    int vrat_uhol_cuvania(int middle);
    void vyrovnavaj(int angle);
    void load_map();
    void update_position(int lstep, int rstep);
    void otocka180();
    Jazda();
private:

};

#endif	/* JAZDA_H */

