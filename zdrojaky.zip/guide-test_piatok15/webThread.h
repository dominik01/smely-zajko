#ifndef WEBTHREAD_H
#define	WEBTHREAD_H

#include <cstdlib>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

extern int turnON;
extern int positionX;
extern int positionY;
extern std::string aktualnaPozicia;

void *web_thread_function(void *ptr);

#endif	/* WEBTHREAD_H */

